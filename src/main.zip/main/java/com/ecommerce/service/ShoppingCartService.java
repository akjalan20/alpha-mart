package com.ecommerce.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.exception.InvalidRequestException;
import com.ecommerce.exception.NotFoundException;
import com.ecommerce.model.Cart;
import com.ecommerce.model.CartDetail;
import com.ecommerce.model.OrderProduct;
import com.ecommerce.model.Product;
import com.ecommerce.repository.CartDetailsRepository;
import com.ecommerce.repository.ShoppingCartRepository;

@Service
public class ShoppingCartService {

	@Autowired
	ShoppingCartRepository cartRepository;

	@Autowired
	CartDetailsRepository cartDetailRepository;

	@Autowired
	ProductService productService;

	public Cart getProductsInCart(String userId) {
		Cart cart = cartRepository.findByUserId(userId);
		cart = calculateTotalDue(cart);
		return cart;
	}
	
	/*@Transactional
	public Cart addProductsToCart(OrderProduct orderProduct, String userId) {
		addProductsInCart(orderProduct, userId);
		Cart cart = getProductsInCart(userId);
		return cart;
	}*/

	/*@Transactional
	public Cart removeProductsFromCart(OrderProduct orderProduct, String userId) {
		removeProductsInCart(orderProduct, userId);
		return getProductsInCart(userId);
	}*/
	
	@Transactional
	public Cart updateProductQuantity(OrderProduct orderProduct, String userId) throws NotFoundException, InvalidRequestException {
		Cart shoppingCart = null;
		if (orderProduct != null) {
			shoppingCart = getProductsInCart(userId);
			if (shoppingCart != null && shoppingCart.getCartId() != 0) {
				List<CartDetail> cartDetailsInDB = shoppingCart.getCartDetails();
				Boolean found = false;
				for (CartDetail cartDetail : cartDetailsInDB) {
					if (cartDetail.getProduct().getProductId() == orderProduct.getProduct().getProductId()) {
						if (orderProduct.getQuantity() == 0) {
							// Delete product from cart if quantity updated to 0
							cartDetailRepository.deleteById(cartDetail.getCartDetailId());
						} else {
							cartDetail.setQuantity(orderProduct.getQuantity());
							//update product quantity in cart
							cartDetailRepository.updateProductQuantity(cartDetail.getQuantity(), cartDetail.getCartDetailId());
						}
						found = true;
					}
				}
				if (!found) {
					throw new NotFoundException("Product not found in cart.");
				}
			} else {
				throw new NotFoundException("Cart does not exist.");
			}
		} else {
			throw new InvalidRequestException("Invalid Request");
		}
		return getProductsInCart(userId);
	}

	@Transactional
	public Cart removeProductsFromCart(OrderProduct orderProduct, String userId) throws NotFoundException, InvalidRequestException {
		Cart shoppingCart = null;
		if (orderProduct != null) {
			shoppingCart = getProductsInCart(userId);
			if (shoppingCart != null && shoppingCart.getCartId() != 0) {
				List<CartDetail> cartDetailInDB = shoppingCart.getCartDetails();
				Boolean found = false;
				for (CartDetail cartDetail : cartDetailInDB) {
					if (cartDetail.getProduct().getProductId() == orderProduct.getProduct().getProductId()) {
						if (cartDetail.getQuantity() == 1) {
							cartDetailRepository.deleteById(cartDetail.getCartDetailId());
						} else {
							cartDetail.setQuantity(cartDetail.getQuantity() - orderProduct.getQuantity());
							// update query
							cartDetailRepository.updateProductQuantity(cartDetail.getQuantity(), cartDetail.getCartDetailId());
						}
						found = true;
					}
				}
				if (!found) {
					throw new NotFoundException("Product not found in cart.");
				}
			}
		} else {
			throw new InvalidRequestException("Invalid Request");
		}
		return getProductsInCart(userId);
	}

	@Transactional
	public Cart addProductsToCart(OrderProduct orderProduct, String userId) throws NotFoundException {
		Cart shoppingCart = null;
		if (orderProduct != null) {
			shoppingCart = getProductsInCart(userId);
			if (shoppingCart != null && shoppingCart.getCartId() != 0) {
				addToCart(orderProduct, shoppingCart);
			} else {
				// Create new cart and add product if not present
				shoppingCart = addShoppingCart(orderProduct, userId);
			}

		}

		return getProductsInCart(userId);
	}

	private void addToCart(OrderProduct orderProduct, Cart shoppingCart) throws NotFoundException {
		List<CartDetail> cartDetailFromDB = shoppingCart.getCartDetails();
		Boolean found = false;
		for (CartDetail cartDetail : cartDetailFromDB) {
			if (cartDetail.getProduct().getProductId() == orderProduct.getProduct().getProductId()) {
				cartDetail.setQuantity(cartDetail.getQuantity() + orderProduct.getQuantity());
				// update product quantity in cart
				cartDetailRepository.updateProductQuantity(cartDetail.getQuantity(), cartDetail.getCartDetailId());
				found = true;				
			}
		}
		if (!found) {
			// add product to cart
			Product product = productService.getProductById(orderProduct.getProduct().getProductId());
			cartDetailRepository.save(new CartDetail(shoppingCart, product, orderProduct.getQuantity()));					
		}

	}

	private Cart addShoppingCart(OrderProduct orderProduct, String userId) throws NotFoundException {
		Cart shoppingCart;
		// create new cart and cart details
		shoppingCart = new Cart();
		shoppingCart.setUserId(userId);
		shoppingCart = cartRepository.save(shoppingCart);
		Product product = productService.getProductById(orderProduct.getProduct().getProductId());
		CartDetail cartDetail = cartDetailRepository.save(new CartDetail(shoppingCart, product, orderProduct.getQuantity()));
		List<CartDetail> cartDetails = new ArrayList<CartDetail>();
		cartDetails.add(cartDetail);
		shoppingCart.setCartDetails(cartDetails);
		return shoppingCart;
	}

	private Cart calculateTotalDue(Cart cart) {
		Float totalDue = 0F;
		if (cart != null) {
			List<CartDetail> orderDetail = cart.getCartDetails();
			for (CartDetail od : orderDetail) {
				totalDue += od.getCartDetailId().getProduct().getPrice() * od.getQuantity();
			}
			cart.setTotalDue(totalDue);
		}

		return cart;
	}

}
