package com.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.exception.NotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.repository.ProductRepository;



@Service
public class ProductService {

	@Autowired
	ProductRepository prdctRepository;

	public List<Product> getAllProducts() {
		return prdctRepository.findAll();
	}

	public Product getProductById(Integer id) throws NotFoundException {
		/*Optional<Product> findByProductId = prdctRepository.findByProductId(id);
		Product product =  findByProductId.get();*/
		Product product = prdctRepository.findByProductId(id).orElseThrow(() -> new com.ecommerce.exception.NotFoundException("Product not found"));
		
		return product;
		
		//findByProductId.orElseThrow(() -> new UsernameNotFoundException("Not Found: "+username));
		//return findByProductId.map(Product::new).get();
			 
	}

	public Product addProduct(Product product) {
		return prdctRepository.save(product);
	}

}
