package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.exception.NotFoundException;
import com.ecommerce.model.Apparel;
import com.ecommerce.model.Book;
import com.ecommerce.model.Product;
import com.ecommerce.service.ProductService;

@RestController	
public class ProductController {
	
	@Autowired
	private ProductService productService;

	@RequestMapping(value="/products", method=RequestMethod.GET)
	public ResponseEntity<List<Product>> getAllProducts() {
		List<Product> products = productService.getAllProducts();
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@RequestMapping(value="/products/{prodId}", method=RequestMethod.GET)
	public ResponseEntity<Product> getProduct(@PathVariable(value="prodId") Integer prodId) throws NotFoundException {
		Product product = productService.getProductById(prodId);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	@RequestMapping(value="/products/book", method=RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Book product) {
		Product newProduct = productService.addProduct(product);
		return new ResponseEntity<Product>(newProduct, HttpStatus.OK);
	}
	
	@RequestMapping(value="/products/apparel", method=RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Apparel product) {
		Product newProduct = productService.addProduct(product);
		return new ResponseEntity<Product>(newProduct, HttpStatus.OK);
	}
}
