package com.ecommerce.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.exception.InvalidRequestException;
import com.ecommerce.exception.NotFoundException;
import com.ecommerce.model.Cart;
import com.ecommerce.model.OrderProduct;
import com.ecommerce.model.Product;
import com.ecommerce.service.ShoppingCartService;

@RestController	
@RequestMapping("/user")
public class ShoppingCartController {
	
	@Autowired
	ShoppingCartService cartService;
	
	/*
	 * API to get all the products in the cart
	 */
	@RequestMapping(value="/{userId}/cart", method=RequestMethod.GET)
	public ResponseEntity<Cart> viewCart(@PathVariable(value="userId") String userId) {
		
		Cart cart = cartService.getProductsInCart(userId);
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}
	
	@RequestMapping(value="/{userId}/cart/product", method=RequestMethod.POST)
	public ResponseEntity<Cart> addToCart(@RequestBody OrderProduct orderProducts, @PathVariable(value="userId") String userId) throws NotFoundException {
		Cart cart = cartService.addProductsToCart(orderProducts, userId);
		
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}
	
	@RequestMapping(value="/{userId}/cart/product", method=RequestMethod.PUT)
	public ResponseEntity<Cart> updateProductQuantity(@RequestBody OrderProduct orderProducts, @PathVariable(value="userId") String userId) throws NotFoundException, InvalidRequestException {
		Cart cart = cartService.updateProductQuantity(orderProducts, userId);
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}
	
	@RequestMapping(value="/{userId}/cart/product", method=RequestMethod.DELETE)
	public ResponseEntity<Cart> deleteFromCart(@RequestBody OrderProduct orderProduct, @PathVariable(value="userId") String userId) throws NotFoundException, InvalidRequestException {
		Cart cart = cartService.removeProductsFromCart(orderProduct, userId);
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}
	
	
	
	@RequestMapping(value="/{userId}/cart/{cartId}", method=RequestMethod.POST)
	public String addCart(@RequestBody Product product, @PathParam(value="userId") String userId, @PathParam(value="cartId") String cartId) {
		return "Pong";
	}
	
	@RequestMapping("/ping")
	public String init() {
		return "Pong";
	}
	
}
