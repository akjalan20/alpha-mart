package com.ecommerce.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	//@SuppressWarnings("rawtypes")
    @ExceptionHandler(NotFoundException.class)
	//@ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorDetail> handle(NotFoundException e) {
		ErrorDetail error = new ErrorDetail();
        error.setMessage(e.getMessage());
        error.setErrors(e.getMessage());
        error.setStatus(HttpStatus.NOT_FOUND);
        return new ResponseEntity<ErrorDetail>(error, HttpStatus.NOT_FOUND);
    }
	
	//@SuppressWarnings("rawtypes")
    @ExceptionHandler(InvalidRequestException.class)
	//@ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorDetail> handle(InvalidRequestException e) {
		ErrorDetail error = new ErrorDetail();
        error.setMessage(e.getMessage());
        error.setErrors(e.getMessage());
        error.setStatus(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<ErrorDetail>(error, HttpStatus.BAD_REQUEST);
    }
	
	//@SuppressWarnings("rawtypes")
    @ExceptionHandler(RuntimeException.class)
	//@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorDetail> handle(RuntimeException e) {
		ErrorDetail error = new ErrorDetail();
        error.setMessage(e.getMessage());
        error.setErrors(e.toString());
        error.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<ErrorDetail>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
}