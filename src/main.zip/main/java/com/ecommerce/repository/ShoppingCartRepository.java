package com.ecommerce.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.model.Cart;
import com.ecommerce.model.Product;

@Repository
public interface ShoppingCartRepository extends JpaRepository<Cart, Integer> {

//Optional<Product> findByProductId(Integer productId);
	
	Optional<Cart> findById(Integer id);
	
	List<Cart> findAll();
	
	Cart save(Cart cart);

	Cart findByUserId(String userId);
	

}
